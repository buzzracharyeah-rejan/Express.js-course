console.log('client side js file is loaded');
