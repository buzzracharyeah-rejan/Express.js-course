const path = require('path');
exports.rootDir = path.join(__dirname);
